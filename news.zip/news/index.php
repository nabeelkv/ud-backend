<?php

include("init.php");
$dbQueries = new dbQueries;

include("includes/header.php");
?>

<body id="yDmH0d" jscontroller="pjICDe" jsaction="rcuQ6b:npT2md; click:FAbpgf; auxclick:FAbpgf;wINJic:.CLIENT;c0v8t:.CLIENT;UjQMac:.CLIENT;keydown:.CLIENT;keyup:.CLIENT;keypress:.CLIENT;nHjqDd:.CLIENT;LhiQec:.CLIENT;GvneHb:.CLIENT;qako4e:.CLIENT;gDJ6Jc:.CLIENT;b18Zgf:.CLIENT;tE0Tse:.CLIENT;u0pjoe:.CLIENT" class="tQj5Y ghyPEc IqBfM e2G3Fb b30Rkd hDsSPc V4dW0 k1PYFe hZmmCc EIlDfe d8Etdd LcUz9d" data-has-footer="true" style="min-height: 851px;" jslog="95013" data-new-gr-c-s-check-loaded="14.1057.0" data-gr-ext-installed="">
	<div class="VUoKZ" aria-hidden="true" style="user-select: auto;">
		<div class="TRHLAc" style="user-select: auto;"></div>
	</div>
	<div aria-hidden="true" class="xIZ6Le" style="user-select: auto;"></div>
	<div class="glbvKf" style="user-select: auto;"></div>
	<div class="pGxpHc" style="user-select: auto;">
		<!-- Nabeel -->
		<header style="display:none;" class="gb_na gb_2a gb_Re gb_Nd gb_Od tabletOrMobileDevice gb_oa" ng-non-bindable="" id="gb" role="banner">
			<div class="gb_7d" style="user-select: auto;">
				
			<div class="gb_Jc gb_Hc gb_oa" ng-non-bindable="" style="overflow-y: auto; user-select: auto; height: calc(851px - 100%);">
					<div class="gb_Sc" style="user-select: auto;">
						<div class="gb_tc" style="user-select: auto;">
							<div class="gb_uc" style="user-select: auto;"><a class="gb_ke gb_vc gb_ie" aria-label="വാർത്തകൾ" href="./?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" title="വാർത്തകൾ" style="user-select: auto;"><span class="gb_zc gb_he" aria-hidden="true" style="user-select: auto;"></span><span class="gb_5d gb_2c" style="user-select: auto;">വാർത്തകൾ</span></a></div>
						</div>
					</div>
					<div class="gb_Oc" style="user-select: auto;"></div>
				</div></div>
			<div class="gb_Md gb_3d gb_Sd gb_Ze" style="user-select: auto;">
				<div class="gb_Ld gb_3c gb_4c" style="user-select: auto;">
					<div class="gb_Ac" aria-expanded="false" aria-label="പ്രധാന മെനു" role="button" tabindex="0" style="user-select: auto;">
						<svg focusable="false" viewBox="0 0 24 24" style="user-select: auto;">
							<path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" style="user-select: auto;"></path>
						</svg>
					</div>
					<div class="gb_Ac gb_Dc gb_ya" aria-label="മടങ്ങുക" role="button" tabindex="0" style="user-select: auto;">
						<svg focusable="false" viewBox="0 0 24 24" style="user-select: auto;">
							<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" style="user-select: auto;"></path>
						</svg>
					</div>
					<div class="gb_Ac gb_Ec gb_ya" aria-label="അടയ്&zwnj;ക്കുക);" role="button" tabindex="0" style="user-select: auto;">
						<svg viewBox="0 0 24 24" style="user-select: auto;">
							<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" style="user-select: auto;"></path>
						</svg>
					</div>
					<div class="gb_tc" style="user-select: auto;">
						<div class="gb_uc" style="user-select: auto;"><a class="gb_ke gb_vc gb_ie" aria-label="വാർത്തകൾ" href="./?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" title="വാർത്തകൾ" id="sdgBod" style="user-select: auto;"><span class="gb_zc gb_he" aria-hidden="true" style="user-select: auto;"></span><span class="gb_5d gb_2c" style="user-select: auto;">വാർത്തകൾ</span></a></div>
					</div>
					<div class="gb_Ld gb_ya gb_1c gb_2c" style="user-select: auto;"><span class="gb_5c" aria-level="1" role="heading" style="user-select: auto;"></span></div>
				</div>
				<div class="gb_Ld gb_Vd gb_He gb_Ee gb_Ke" style="user-select: auto;">
					<div class="gb_Fe" style="user-select: auto;">
						<form class="gb_Te gb_Ee VISqTe" method="get" role="search" style="user-select: auto;">
							<button class="gb_pf" aria-label="തിരയൽ അടയ്&zwnj;ക്കുക" type="button" style="user-select: auto;">
								<svg focusable="false" height="24px" viewBox="0 0 24 24" width="24px" xmlns="http://www.w3.org/2000/svg" style="user-select: auto;">
									<path d="M0 0h24v24H0z" fill="none" style="user-select: auto;"></path>
									<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" style="user-select: auto;"></path>
								</svg>
							</button>
							<div class="gb_uf" style="user-select: auto;">
								<div class="gb_ef gb_vf" style="user-select: auto;">
									<div class="TMT2L" jscontroller="U4Hp0d" jsaction="rcuQ6b:rcuQ6b;fRPOBb:ti6hGc;isz31c:ZYIfFd;" style="user-select: auto;">
										<div class="Mxgq5c" jsname="haAclf" jscontroller="MxVzvd" jsaction="CLIdJb:MN2rZe;v819Lb:NLjNtd;fRPOBb:JFZiG;rcuQ6b:npT2md;wmWsCf:KuiYke;" style="user-select: auto;">
											<div class="L6J0Pc VOEIyf g4E9Cb Yonv" jscontroller="Mq9n0c" jsaction="keydown:I481le; focus: AHmuwe;AHmuwe:AHmuwe; mouseenter:npT2md;Mu8aMc:YPqjbf;Edq9ub:SDqDXe;e0gSlf:pX1iqf;" data-close-on-blur="true" jsname="h0T7hb" data-renderer="g2JDKf" data-service="VkjdHd" style="user-select: auto;">
												<div class="d1dlne" jscontroller="K99qY" jsname="YPqjbf" style="position: relative; user-select: auto;" data-placeholder="തിരയുക" data-activedescendants="true">
													<input class="yNVtPc ZAGvjd Ny5lGc" disabled="true" aria-hidden="true" jsname="A51lKb" value="തിരയുക" dir="ltr" style="user-select: auto;">
													<input class="Ax4B8 ZAGvjd" type="text" autocomplete="off" aria-label="തിരയുക" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" role="combobox" jsname="dSO9oc" jsaction="input:YPqjbf; keydown:I481le; click:cOuCgd" aria-controls="nngdp367" style="user-select: auto;">
												</div>
												<div class=" tWfTvb" style="user-select: auto;">
													<div class="u3WVdc jBmls" tabindex="-1" role="listbox" data-expanded="false" data-childcount="0" jsname="iuXDpb" jsaction="mousedown:npT2md(preventDefault=true);" id="nngdp367" style="user-select: auto;"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<button class="gb_qf" aria-label="തിരയല്&zwj;&zwnj; മായ്&zwnj;ക്കുക" type="button" style="user-select: auto;">
								<svg focusable="false" height="24px" viewBox="0 0 24 24" width="24px" xmlns="http://www.w3.org/2000/svg" style="user-select: auto;">
									<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" style="user-select: auto;"></path>
									<path d="M0 0h24v24H0z" fill="none" style="user-select: auto;"></path>
								</svg>
							</button>
							
							<div style="display: none; user-select: auto;"></div>
						<div style="display: none;"></div></form>
					</div>
				</div>
				<div class="gb_Wd gb_Za gb_Ld" ng-non-bindable="" data-ogsr-up="" style="user-select: auto;">
					<div class="gb_Se" style="user-select: auto;">
						<div class="gb_Tc" style="user-select: auto;">
							<div class="gb_z gb_hd gb_f gb_Af" data-ogsr-fb="true" data-ogsr-alt="" id="gbwa" style="user-select: auto;">
								<div class="gb_zf" style="user-select: auto;">
									<a class="gb_A" aria-label="Google ആപ്സ്" href="https://www.google.co.in/intl/ml/about/products?tab=nh" aria-expanded="false" role="button" tabindex="0" style="user-select: auto;">
										<svg class="gb_Ve" focusable="false" viewBox="0 0 24 24" style="user-select: auto;">
											<path d="M6,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,20c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM6,20c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM6,14c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,14c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM16,6c0,1.1 0.9,2 2,2s2,-0.9 2,-2 -0.9,-2 -2,-2 -2,0.9 -2,2zM12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM18,14c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM18,20c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2z" style="user-select: auto;"></path>
										</svg>
									</a>
								</div>
							</div>
						</div>
						
					</div>
					<div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 328px; z-index: 991; height: 0px; margin-top: 57px; transition: height 0.3s ease-in-out 0s; right: 0px; margin-right: 4px; user-select: auto;"></div>
					<div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 372px; z-index: 991; height: 0px; margin-top: 57px; right: 0px; margin-right: 4px; user-select: auto;"></div>
				<div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 328px; z-index: 991; height: 0px; margin-top: 57px; transition: height 0.3s ease-in-out 0s; right: 0px; margin-right: 4px;"></div><div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 372px; z-index: 991; height: 0px; margin-top: 57px; right: 0px; margin-right: 4px;"></div>

					<!-- Nabeel -->
				<div style="display: none;overflow: hidden; position: absolute; top: 0px; width: 100%; z-index: 991; height: 448px; margin-top: 57px; transition: height 0.3s ease-in-out 0s; right: 0px; margin-right: 0px; max-height: calc(-61px + 100vh);">

					<div style="box-shadow:0 -1px 2px 0 rgba(60,64,67,0.30),0 -2px 6px 2px rgba(60,64,67,0.15);height:calc(100% - 16px);left:0;margin:8px;position:absolute;top:0;width:calc(100% - 16px);background:#FFF;"><div style="font:14px/22px Roboto,RobotoDraft,Arial,sans-serif;letter-spacing:0.03px;padding:134px 50px;text-align:center;white-space:normal;color:#5F6368;" data-fb=""> <svg height="28px" viewBox="0 0 24 24" width="28px" xmlns="http://www.w3.org/2000/svg"> <path fill="#80868B" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path> </svg> <p style="margin-top:4px;"> ആപ്പുകളുടെ ഗണം ലോഡ് ചെയ്യുന്നതിൽ ഒരു പ്രശ്&amp;zwnj;നമുണ്ടായി. അൽപ്പസമയത്തിന് ശേഷം വീണ്ടും ശ്രമിക്കുകയോ  <a style="font:14px/22px Roboto,RobotoDraft,Arial,sans-serif;font-weight:bold;letter-spacing:0.03px;text-decoration:none;color:#4285F4;" target="_blank" href="https://www.google.co.in/intl/ml/about/products?tab=nh">Google ഉൽപ്പന്നങ്ങൾ</a>  പേജിലേക്ക് പോകുകയോ ചെയ്യുക. </p> </div></div></div><div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 372px; z-index: 991; height: 0px; margin-top: 57px; right: 0px; margin-right: 4px;"></div></div>
			</div>
			<div class="gb_Td gb_3d" style="user-select: auto;"></div>
		</header>
		<div class="gb_Pd" style="height: 56px; user-select: auto;"></div>
	</div>
	
	<c-wiz jsrenderer="qeKLuc" class="zQTmif SSPGKf ZYcfVd oCHqfe JwkDRc BIIBbc" jsdata="deferred-i1" data-p="%.@.[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,3,[],[],1]" jsname="a9kxte" data-node-index="0;0" jsmodel="hc6Ubd" view="" c-wiz="" data-ogpc="" style="user-select: auto; position: fixed; inset: -191px 0px -2374px; display: none; visibility: hidden; opacity: 0;" data-savedfocusid="150" data-savescroll="191" aria-busy="true" aria-hidden="true">
		<div class="T4LgNb" jsname="a9kxte" style="user-select: auto;">
			<div class="VjFXz" style="user-select: auto;"></div>
			<div class="FVeGwb CVnAc Haq2Hf bWfURe" jscontroller="BeJYtf" jsaction="rcuQ6b:npT2md;kfsncb:QnC63e;" jslog="83496; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLDE0MSxudWxsLG51bGwsbnVsbCwzMDFd; track:vis" data-n-et="422" jsmodel="FSc7tf lPJ2ac" style="user-select: auto;">
				<div jsname="ReIlqe" data-n-pt="6" style="user-select: auto;"></div>
				<div class="ajwQHc BL5WZb zLBZs" style="user-select: auto;">
					<div class="tsldL Oc0wGc" style="user-select: auto;">
						<main class="HKt8rc CGNRMc" jsname="fjw8sb" jslog="94187; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLDE0MSxudWxsLG51bGwsbnVsbCwzMDFd" style="user-select: auto;">
							<div jscontroller="fAYBsd" jsaction="rcuQ6b:npT2md" style="user-select: auto;"></div>
							<c-wiz jsrenderer="OIIjLd" class="FTc2fd" data-n-nap="1" data-n-prms="[null,6,1,false,3,[],null,[1],null]" jsdata="deferred-i2" data-p="%.@.[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,null,null,3,[],[],1]" jscontroller="o8u3Cf" jsaction="rcuQ6b:npT2md;" data-node-index="1;0" jsmodel="hc6Ubd Hjkoe" c-wiz="" style="user-select: auto;">
								<div class="lBwEZb BL5WZb xP6mwf ENDuKc Au3bp" jsname="esK7Lc" jscontroller="SpTAFc" jsmodel="dPwZPd hT8rr" jsdata="tbf4if;ui|124+510ac017-3647-4d8e-b3fc-6c870295f0ba,ui|124+97547700-ce26-4b96-a438-026664df258b;4" data-n-et="200" data-n-ham="true" style="user-select: auto;">
									<div jslog="88374; 3:W251bGwsbnVsbCxudWxsLG51bGwsInNlY3Rpb24tdG9waWMtbWlkOi9tLzA1amhnIixudWxsLDE0MSxudWxsLG51bGwsbnVsbCwzMDEsbnVsbCxudWxsLFtbWyIvbS8wNWpoZyJdXSxudWxsLDhdXQ==; track:vis ; index:0" class="iKGKEb tXImLc Oc0wGc lBwEZb Au3bp sfxiOc R7GTQ keNKEd " style="user-select: auto;">
										<div class="dSva6b JQQdOc  yETrXb Ir3o3e Au3bp sbWPef R7GTQ keNKEd j7vNaf " data-n-hl="ml" jsdata="tbf4if;ui|124+942c1b1e-d0b2-42e0-a166-4d9c0e43bb22,ui|124+684daa0c-e30c-43bf-a51a-118bdc065f19;5" jsmodel="hT8rr" data-n-ham="true" id="i3" style="user-select: auto;">
											<div class="cp7Yvc" style="user-select: auto;">
												<h2 class="oOr8M  yETrXb Ir3o3e Au3bp cS3HJf" jsname="smh91d" style="user-select: auto;"><span jscontroller="MfVatf" jsaction="click:KjsqPd" jslog="108423; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSmdnS0lpQkRRa0ZUUldkdlNVd3lNSFpOUkZaeFlVZGpVMEZ0TVhOSFowcEtWR2xuUVZBQiJdXQ==" data-n-et="1501" data-n-ca-at="1" data-n-ci-wu="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRFZxYUdjU0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" style="user-select: auto;"><a href="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRFZxYUdjU0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="wmzpFf  yETrXb Ir3o3e Au3bp ndj7Ed" style="user-select: auto;">തലക്കെട്ടുകൾ</a></span></h2></div>
										</div>
										<div class="NWHX8c pOFxF Au3bp mi8Lec  R7GTQ keNKEd j7vNaf" jsmodel="analyticsModelWiz.id" data-n-et="1605" data-n-ham="true" data-n-cvid="i5" jsdata="tbf4if;ui|124+f080fcab-ca35-4c71-8f0b-972c96ee3b4b,ui|124+4595ee9b-e581-41c8-8c6e-110ef31377eb;6" jslog="127548; 3:W251bGwsbnVsbCxudWxsLG51bGwsImNoYW5uZWxfc3RvcnlfMzYwOkNBQXFOZ2dLSWpCRFFrbFRTR3B2U21NelVuWmpibXQwVFhwWmQxTm9SVXRFZDJvM01FNWhWa0pTU0hORmJqZGFVVlJtVUVKRFowRlFBUSIsbnVsbCwxNDEsbnVsbCxudWxsLG51bGwsMzAxLG51bGwsbnVsbCxbW1siL20vMDVqaGciXV0sMSw0XV0=; track:vis; index:0" style="user-select: auto;">
											
										<div data-n-et="1606" data-n-ham="true" data-n-cvid="i7" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;8" jsmodel="hT8rr" jscontroller="w22xSc" jsaction="rcuQ6b:npT2md;" style="user-select: auto;">
											<div class="SJyhnc PqkbTd" jsshadow="" style="user-select: auto;">
												<div jsslot="" class="NBZP0e xbmkib" jscontroller="XTf4dd" jsaction="" data-snap-point="0" data-snap-debounce-ms="250" data-snap-animation-ms="300" jslog="126735; 3:W10=; track:vis; index:1" style="user-select: auto;">
													<article class=" MQsxIb xTewfe FSATdd Au3bp EjqUne msTxEe" jscontroller="HyhIue" jsaction=";rcuQ6b:npT2md; click:KjsqPd;" jsmodel="a4N6Ae hT8rr" jslog="85008; 3:W251bGwsbnVsbCxudWxsLG51bGwsImNoYW5uZWxfc3RvcnlfMzYwOkNBQXFOZ2dLSWpCRFFrbFRTR3B2U21NelVuWmpibXQwVFhwWmQxTm9SVXRFZDJvM01FNWhWa0pTU0hORmJqZGFVVlJtVUVKRFowRlFBUSIsMCwxNDEsbnVsbCxudWxsLFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLCJhOWI0N2M5Ny00MTZlLTRlZmQtODEzZC05NTc5MWQ0Njc0MzAiXSwzMDEsbnVsbCxudWxsLFtbWyIvbS8wNWpoZyJdXSwxLDRdLG51bGwsMV0=; track:vis; index:0" ve-visible="false" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;8" data-kind="2" data-n-ham="true" data-n-et="107" data-n-cvid="i8" data-n-vlb="0" data-n-suav="true" style="user-select: auto;">
														<a class="VDXfz" jsname="hXwDdf" jslog="95014; 5:W251bGwsbnVsbCwiaHR0cHM6Ly93d3cubWF0aHJ1Ymh1bWkuY29tL2NyaW1lL25ld3MvcGFsYWtrYWQtc3JlZW5pdmFzYW4tbXVyZGVyLWNhc2UtZXZpZGVuY2UtdGFraW5nLXdpdGgtYWNjdXNlZC0xLjc0NjMwNzkiLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCwiaHR0cHM6Ly93d3cubWF0aHJ1Ymh1bWkuY29tL2FtcC9jcmltZS9uZXdzL3BhbGFra2FkLXNyZWVuaXZhc2FuLW11cmRlci1jYXNlLWV2aWRlbmNlLXRha2luZy13aXRoLWFjY3VzZWQtMS43NDYzMDc5Il0=; track:click,vis" href="https://google.com" tabindex="-1" aria-hidden="true" style="user-select: auto;"></a>
														<div class="wsLqz RD0gLb Rgstwe" style="user-select: auto;"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme IGhidc" srcset="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=s0-h14-rw 1x, https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=s0-h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=s0-h14-rw" loading="lazy" style="user-select: auto;"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme b1F67d" srcset="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=s0-h14-rw 1x, https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=s0-h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=s0-h14-rw" loading="lazy" style="user-select: auto;"><img class="tvs3Id tvs3Id lqNvvd lITmO WfKKme" jsname="mgY0Ed" srcset="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=s0-h24-rw 1x, https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=s0-h48-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=s0-h24-rw" loading="lazy" style="user-select: auto;"><a href="./publications/CAAqBggKMLqiLTCnmQU?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="wEwyrc AVN2gc WfKKme " data-n-tid="9" style="user-select: auto;">Mathrubhumi</a></div>
														<h5 class="ipQwMb ekueJc RD0gLb" style="user-select: auto;"><a href="https://google.com" class="DY5T1d RZIKme" style="user-select: auto;">ശ്രീനിവാസന്&zwj; വധക്കേസ്: പ്രതിയുമായി തെളിവെടുപ്പ്, സ്&zwnj;കൂട്ടര്&zwj; കണ്ടെടുത്തു</a></h5>
														<div class="QmrVtf RD0gLb kybdz" style="user-select: auto;">
															<div class="SVJrMe" jsname="Hn1wIf" style="user-select: auto;">
																<svg height="18" viewBox="0 0 24 24" width="18" focusable="false" class="N3ElHc eLNT1d uQIVzc NMm5M" style="user-select: auto;">
																	<path d="M0 0h24v24H0V0z" fill="none" style="user-select: auto;"></path>
																	<path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z" style="user-select: auto;"></path>
																</svg>
																<time class="WW6dff uQIVzc Sksgp" datetime="2022-04-25T09:01:48Z" style="user-select: auto;">9 മണിക്കൂർ മുമ്പ്</time>
															</div>
															<menu class="fmkQje gXqRq" style="user-select: auto;"><span class=" L8PZAb GB1Zid" jscontroller="jSvZHb" jsmodel="WDTLsd BZ12ub" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;8 tbf4if;ui|124+f080fcab-ca35-4c71-8f0b-972c96ee3b4b,ui|124+4595ee9b-e581-41c8-8c6e-110ef31377eb;6" jsaction="rcuQ6b:npT2md;aWRkAb:u0WEMd;h4C2te:Oy8cwd;" data-n-prms="[true,true,false,null,false,false,false,false,null,false,true]" jslog="109017" style="user-select: auto;"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e uUmIDd gL67me cd29Sd V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="S9Bhuc" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="കൂടുതൽ&zwj;" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-dynamic="true" style="user-select: auto;"><div class="XI1L0d zSBur" jsname="ksKsZd" style="user-select: auto;"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job" style="user-select: auto;">more_vert</span></div>
														</span>
														</menu>
												</div>
												</article>
												
				
		
		</div>
		</div>
		<div class="FGOkNb" jsname="Hzufd" style="user-select: auto;"></div>
		<div class="MH4CV" jsaction="ZYIfFd:QdqIqe" style="user-select: auto;">
			<div class="EmVfjc CxE4Ze eLNT1d" data-loadingmessage="ലോഡുചെയ്യുന്നു..." jscontroller="qAKInc" jsaction="animationend:kWijWc;dyRcpb:dyRcpb" jsname="aZ2wEe" data-active="false" style="user-select: auto;">
				<div class="Cg7hO" aria-live="assertive" jsname="vyyg5" style="user-select: auto;"></div>
				<div jsname="Hxlbvc" class="xu46lf" style="user-select: auto;">
					<div class="ir3uv uWlRce co39ub" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
					<div class="ir3uv GFoASc Cn087" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
					<div class="ir3uv WpeOqd hfsr6b" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
					<div class="ir3uv rHV3jf EjXFBf" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<c-data id="i2" jsdata=" CjGeoc;aa|124+ui|124+510ac017-3647-4d8e-b3fc-6c870295f0ba,;3" style="user-select: auto;"></c-data>
		</c-wiz>
		</main>
		</div>
		</div>
		<div jscontroller="NG09oe" jsaction="rcuQ6b:DMq1fb" data-tracker-id="" style="user-select: auto;"></div>
		</div>
		</div>
		<c-data id="i1" jsdata=" CjGeoc;aa|124+ui|124+0bbf5bee-4f4d-489f-a005-ee0b8b3176a4,2;2 CjGeoc;aa|124+ui|124+510ac017-3647-4d8e-b3fc-6c870295f0ba,;3" style="user-select: auto;"></c-data>
	</c-wiz>
	<c-wiz jsrenderer="fWqNsd" class="zQTmif SSPGKf" jsdata="deferred-c10" data-p="%.@.&quot;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ&quot;,null,false,[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;,null,330],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,[8,null,0],0,3,null,false,true]" jsname="a9kxte" data-node-index="0;0" jsmodel="hc6Ubd" c-wiz="" data-ogpc="" style="visibility: visible; opacity: 1;" aria-busy="false" data-savescroll="0">
		<div class="T4LgNb" jsname="a9kxte">
			<div class="VjFXz"></div>
			<div class="FVeGwb CVnAc Haq2Hf bWfURe" jscontroller="BeJYtf" jsaction="rcuQ6b:npT2md;kfsncb:QnC63e;" data-n-tid="22" data-n-et="405" jsdata="KX46Ye;_;$23" data-n-ham="true" jsmodel="FSc7tf hT8rr lPJ2ac">
				<div jsname="ReIlqe" data-n-pt="8"></div>
				<c-wiz jsrenderer="xz9Esf" class="MNK4Vd Au3bp" jslog="88531; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxTmdnS0lqQkRRa2xUU0dwdlNtTXpVblpqYm10MFRYcFpkMU5vUlV0RWQybzNNRTVoVmtKU1NITkZiamRhVVZSbVVFSkRaMEZRQVEiXSxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtdXQ==; track:vis" data-n-prms="[8,&quot;&quot;,0,true,false,1,false,true,false,false]" data-n-et="405" data-n-ham="true" jsdata="deferred-c9" data-p="%.@.&quot;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ&quot;,null,false,[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;,null,330],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,0,3,null,false,true]" jscontroller="NM85mf" jsaction="eDLhle:jyPbt;rcuQ6b:WcZlOd;" data-node-index="1;0" jsmodel="hc6Ubd cgol3b hT8rr" c-wiz="">
					<div>
						<!-- Nabeel -->
						<div style="display:none;" class="XCz6Hb rHXK0e PIHOaf Au3bp Y2z0Bd" jsdata="FxLhne;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ;$0" jsmodel="LVE0b" jscontroller="H39Hkc" jsaction="rcuQ6b:npT2md;">
							<div class="giq3T">
								<div class="VxptDf">
									<div class="Un8Mu">
										<div class="xwumSd" data-n-tid="13"><img class="OxQPVc" alt="" src="https://lh3.googleusercontent.com/JDFOyo903E9WGstK0YhI2ZFOKR3h4qDxBngX5M8XJVBZFKzOBoxLmk3OVlgNw9SOE-HfkNgb=w40-rw" data-iml="1617.5" data-atf="true">സമ്പൂർണ്ണ റിപ്പോർട്ട്</div>
									</div>
									<div class="boLjl">
										<div class="jKS7Jd">
											<div role="button" class="U26fgb c7fp5b FS4hgd jKS7Jd" jscontroller="iSvg6e" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;" jsshadow="" jsname="iwqCHe" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-alignright="true" data-vertical-menu-offset="-6">
												<div class="lVYxmb MbhUzd" jsname="ksKsZd"></div>
												<div class="g4jUVc" aria-hidden="true"></div><span jsslot="" class="I3EnF oJeWuf"><span class="NlWrkb snByac"><div class="u43Gd">അടുക്കുക<span class="DPvwYc BiCknd" aria-hidden="true"></span></div>
											</span>
											</span>
											<div jsname="xl07Ob" style="display:none" aria-hidden="true">
												<div class="JPdR6b CblTmf FxcLv" jscontroller="uY3Nvd" jsaction="IpSVtb:TvD9Pc;fEN2Ze:xzS4ub;frq95c:LNeFm;cFpp9e:J9oOtd; click:H8nU8b; mouseup:H8nU8b; keydown:I481le; keypress:Kr2w4b; blur:O22p3e; focus:H8nU8b" role="menu" tabindex="0" jsshadow="">
													<div class="XvhY1d" jsaction="mousedown:p8EH2c; touchstart:p8EH2c;">
														<div class="JAPqpe K0NPx"><span jsslot="" class="z80M1 N2RpBe Mj6npd" jsaction="click:o6ZaF(preventDefault=true); mousedown:lAhnzb; mouseup:Osgxgf; mouseenter:SKyDAe; mouseleave:xq3APb;touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8(preventMouseEvents=true)" jsname="j7LFlb" aria-label="പ്രാധാന്യമനുസരിച്ച്" role="menuitem" tabindex="-1"><div class="aBBjbd MbhUzd" jsname="ksKsZd"></div><div class="uyYuVb oJeWuf" jscontroller="grDm0d" jsaction="JIbuQc:Hztlm"><div class="jO7h3c">പ്രാധാന്യമനുസരിച്ച്</div></div></span><span jsslot="" class="z80M1 Mj6npd" jsaction="click:o6ZaF(preventDefault=true); mousedown:lAhnzb; mouseup:Osgxgf; mouseenter:SKyDAe; mouseleave:xq3APb;touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8(preventMouseEvents=true)" jsname="j7LFlb" aria-label="തീയതി പ്രകാരം" role="menuitem" tabindex="-1"><div class="aBBjbd MbhUzd" jsname="ksKsZd"></div><div class="uyYuVb oJeWuf" jscontroller="grDm0d" jsaction="JIbuQc:TftXlc;"><div class="jO7h3c">തീയതി പ്രകാരം</div></div></span></div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="MSFRuc Q3T0Df"><span jscontroller="ZHduwf" jsmodel="tOLjce hECoeb" jsaction="JIbuQc:RNDhHe;" jsdata="FxLhne;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ;$1" data-n-et="1000" data-n-ca-at="8"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e co57Bf cd29Sd dHeVVb V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="zbPkme" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="പങ്കിടുക" aria-disabled="false" tabindex="0" data-n-et="1000"><div class="XI1L0d zSBur" jsname="ksKsZd"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job">share</span><span class="iDvCIf xfudi">പങ്കിടുക</span></div>
									</span>
								</div>
							</div>
						</div>
						<div class="apU4O">
							<div class="xMjzl"></div>
						</div>
					</div>
			</div>
			<div class="ajwQHc BL5WZb">
				<div class="tsldL Oc0wGc">
					<main class="HKt8rc CGNRMc" jsname="fjw8sb">
						<c-wiz jsrenderer="optrU" class="Vlf0vb" jslog="" data-n-et="405" data-n-ham="true" data-n-prms="[8,1,false,false,3,0,false]" jsdata="deferred-c8" data-p="%.@.null,null,&quot;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ&quot;,false,[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;,null,330],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,null,0,3,null,false,true]" jscontroller="uzO99c" jsaction="rcuQ6b:npT2md;wQCqwd:vNq42e;" data-node-index="1;0" jsmodel="hc6Ubd be99Xd hT8rr" c-wiz="">
							<div class="ajwQHc BL5WZb">
								<div class="tsldL Oc0wGc">
									<main class="HKt8rc CGNRMc" jsname="fjw8sb" jslog="134946">
										<div class="lBwEZb BL5WZb xP6mwf ENDuKc Au3bp" jsname="esK7Lc" jscontroller="SpTAFc" jsmodel="dPwZPd hT8rr" jsdata="tbf4if;CAQiZ0NCSVNSem9KYzNSdmNua3RNell3UWdodmRtVnlkbWxsZDBvUkNnOEktOURXbFFVUjdCSi0yVUUzendSeUhRb2JDaGxUVkU5U1dWOHpOakJmU0VWQlJFVlNYMDlXUlZKV1NVVlhLQUEqOggAKjYICiIwQ0JJU0hqb0pjM1J2Y25rdE16WXdTaEVLRHdqNzBOYVZCUkhzRW43WlFUZlBCQ2dBUAFQAQ,;$2" data-n-et="200" data-n-ham="true">
											<div class="w0Adec Oc0wGc lMgtcc R7GTQ keNKEd j7vNaf " jslog="88374; 3:W251bGwsbnVsbCxudWxsLG51bGwsIk5FV1NfVE9QX0NPVkVSQUdFX1JFU1VMVF9HUk9VUCIsbnVsbCwxNDEsbnVsbCxudWxsLG51bGwsNTksbnVsbCxudWxsLFtdLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtdXQ==; track:vis; index:0" data-n-tid="14">
												<div class="pjBVq mi8Lec D6Jf dIgQgd EOlQu Oc0wGc Au3bp R7GTQ keNKEd j7vNaf" jsmodel="hT8rr" jsdata="KX46Ye;_;$3" data-n-ham="true">
													<!-- <div class="dSva6b JQQdOc  yETrXb Ir3o3e Au3bp sbWPef R7GTQ keNKEd j7vNaf " data-n-hl="ml" jsdata="tbf4if;ui|124+10adb768-9313-425c-b83f-0798fe1d98a7,ui|124+e599066d-71a6-40b5-be7e-8ee4631e8042;$4" jsmodel="hT8rr" data-n-ham="true" id="c1">
														<div class="cp7Yvc">
															<h2 class="oOr8M  yETrXb Ir3o3e Au3bp cS3HJf" jsname="smh91d">പ്രധാന വാർത്തകൾ</h2></div>
													</div> -->
													<div class="ndSf3d eDrqsc eVhOjb Oc0wGc j7vNaf dIgQgd" jsname="gKDw6b">

														<!-- Nabeel -->
														<article class=" MQsxIb xTewfe tXImLc Xpocq R7GTQ keNKEd keNKEd Au3bp VkAdve GU7x0c g1F8Ld mSjmrf msTxEe" jscontroller="HyhIue" jsaction=";rcuQ6b:npT2md; click:KjsqPd;" jsmodel="a4N6Ae hT8rr" jslog="85008; 3:W251bGwsbnVsbCxudWxsLG51bGwsIk5FV1NfVE9QX0NPVkVSQUdFX1JFU1VMVF9HUk9VUCIsMCwxNDEsbnVsbCxudWxsLG51bGwsNTksbnVsbCxudWxsLFtdLG51bGwsMSxudWxsLG51bGwsbnVsbCxudWxsLFtdXQ==; track:vis; index:0" ve-visible="true" jsdata="oM6qxc;CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s;$5" data-kind="13" data-n-ham="true" data-n-et="107" data-n-cvid="c2" data-n-vlb="0" data-n-suav="true">
															<a class="VDXfz" jsname="hXwDdf" jslog="95014; 5:W251bGwsbnVsbCwiaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmh0bWwiLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCwiaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1sIixudWxsLG51bGwsW11d; track:click,vis" href="./articles/CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" tabindex="-1" aria-hidden="true"></a>
															<figure jscontroller="dAR81" jsaction="error:HLDri" class="AZtY5d fvuwob  RD0gLb"><img class="tvs3Id QwxBBf" srcset="https://lh3.googleusercontent.com/proxy/ku0sL0ViPLR5dnjGqhIDoba3Ls9uIRd5xNphHJE_qJJQQ0YtziWqDK9-R6v4XMGpTdTedKQnAFMFmcR9z5aubncYfL0TVOgtU_wPcGZlyMic47D6NwdNO9NPb7e41zT0Szdtur90zAdpuGXBCUHHOuAl2GQeD-0lRPx3lhXzgpETXsW3QRiv9zjlOa1_HTRnSYyF-zPj9NAyGpG_d3hxkws=w350-h175-rw-dcDYCUSLQH 1x, https://lh3.googleusercontent.com/proxy/ku0sL0ViPLR5dnjGqhIDoba3Ls9uIRd5xNphHJE_qJJQQ0YtziWqDK9-R6v4XMGpTdTedKQnAFMFmcR9z5aubncYfL0TVOgtU_wPcGZlyMic47D6NwdNO9NPb7e41zT0Szdtur90zAdpuGXBCUHHOuAl2GQeD-0lRPx3lhXzgpETXsW3QRiv9zjlOa1_HTRnSYyF-zPj9NAyGpG_d3hxkws=w700-h350-rw-dcDYCUSLQH 2x" aria-label="ഇമേജ്" alt="" src="https://lh3.googleusercontent.com/proxy/ku0sL0ViPLR5dnjGqhIDoba3Ls9uIRd5xNphHJE_qJJQQ0YtziWqDK9-R6v4XMGpTdTedKQnAFMFmcR9z5aubncYfL0TVOgtU_wPcGZlyMic47D6NwdNO9NPb7e41zT0Szdtur90zAdpuGXBCUHHOuAl2GQeD-0lRPx3lhXzgpETXsW3QRiv9zjlOa1_HTRnSYyF-zPj9NAyGpG_d3hxkws=w350-h175-rw-dcDYCUSLQH" importance="high" jslog="131347" loading="lazy"></figure>
															<div class="wsLqz RD0gLb"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme IGhidc" srcset="https://lh3.googleusercontent.com/iu2FMOg_Yf2g0ydlI9pw1H8fIrB5hClaFB-XFiDdNqXGiAhe5urQEwQYNxKKuGvdNrXa1KVrew=h14-rw 1x, https://lh3.googleusercontent.com/iu2FMOg_Yf2g0ydlI9pw1H8fIrB5hClaFB-XFiDdNqXGiAhe5urQEwQYNxKKuGvdNrXa1KVrew=h28-rw 2x" aria-label="ഇമേജ് - Manorama Online" alt="Manorama Online" src="https://lh3.googleusercontent.com/iu2FMOg_Yf2g0ydlI9pw1H8fIrB5hClaFB-XFiDdNqXGiAhe5urQEwQYNxKKuGvdNrXa1KVrew=h14-rw" loading="lazy"><img class="tvs3Id tvs3Id lqNvvd lITmO WfKKme" jsname="mgY0Ed" srcset="https://encrypted-tbn0.gstatic.com/faviconV2?url=https://www.manoramaonline.com&amp;client=NEWS_360&amp;size=96&amp;type=FAVICON&amp;fallback_opts=TYPE,SIZE,URL 1x, https://encrypted-tbn0.gstatic.com/faviconV2?url=https://www.manoramaonline.com&amp;client=NEWS_360&amp;size=96&amp;type=FAVICON&amp;fallback_opts=TYPE,SIZE,URL 2x" aria-label="ഇമേജ് - Manorama Online" alt="Manorama Online" src="https://encrypted-tbn0.gstatic.com/faviconV2?url=https://www.manoramaonline.com&amp;client=NEWS_360&amp;size=96&amp;type=FAVICON&amp;fallback_opts=TYPE,SIZE,URL" loading="lazy"><a class="wEwyrc AVN2gc WfKKme " data-n-tid="9">Manorama Online</a></div>
															<h4 class="ipQwMb ekueJc RD0gLb"><a href="./articles/CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="DY5T1d RZIKme">പാലക്കാട് എസ്&zwj;ഡിപിഐ ഓഫിസില്&zwj; റെയ്ഡ്; ചില രേഖകൾ കിട്ടിയെന്ന് പൊലീസ്</a></h4>
															<div class="QmrVtf RD0gLb kybdz">
																<div class="SVJrMe" jsname="Hn1wIf">
																	<svg height="18" viewBox="0 0 24 24" width="18" focusable="false" class="N3ElHc eLNT1d uQIVzc NMm5M">
																		<path d="M0 0h24v24H0V0z" fill="none"></path>
																		<path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"></path>
																	</svg>
																	<time class="WW6dff uQIVzc Sksgp" datetime="2022-04-25T15:35:12Z">2 മണിക്കൂർ മുമ്പ്</time>
																</div>
																<menu class="fmkQje gXqRq"><span class=" L8PZAb GB1Zid" jscontroller="jSvZHb" jsmodel="WDTLsd BZ12ub" jsdata="oM6qxc;CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s;$6 tbf4if;ui|124+10adb768-9313-425c-b83f-0798fe1d98a7,ui|124+e599066d-71a6-40b5-be7e-8ee4631e8042;$7" jsaction="rcuQ6b:npT2md;aWRkAb:u0WEMd;h4C2te:Oy8cwd;" data-n-prms="[true,true,false,null,false,false,false,false,null,false,false]" jslog="109017"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e uUmIDd gL67me cd29Sd V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="S9Bhuc" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="കൂടുതൽ&zwj;" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-dynamic="true"><div class="XI1L0d zSBur" jsname="ksKsZd"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job">more_vert</span></div>
															</span>
															</menu>
													</div>
													</article>

<?php 
    
    if($dbQueries->Query("SELECT * FROM mannarkkad")) {
                           
        $totalRecords = $dbQueries->rowCount();
        $dbQueries->Query("SELECT * FROM mannarkkad LIMIT 0,10");
                           
        $newses = $dbQueries->fetchAll();
        $rowCount = $dbQueries->rowCount();
                           
    if($rowCount > 0){
                           
        foreach($newses as $id=>$news) { ?>
            									
												
											<article class=" MQsxIb xTewfe tXImLc R7GTQ keNKEd keNKEd Au3bp VkAdve GU7x0c JMJvke q4atFc msTxEe">
												<a class="VDXfz" tabindex="-1" aria-hidden="true" href="<?php echo $news->link; ?>"></a>
												<figure jscontroller="dAR81" jsaction="error:HLDri" class="AZtY5d fvuwob  RD0gLb"><img class="tvs3Id QwxBBf" srcset="<?php echo $news->image; ?> 2x" aria-label="ഇമേജ്" alt="" src="<?php echo $news->image; ?>" loading="lazy"></figure>
												<div class="wsLqz RD0gLb"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme IGhidc" srcset="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=h14-rw 1x, https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=h14-rw" loading="lazy"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme b1F67d" srcset="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=h14-rw 1x, https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=h14-rw" loading="lazy"><img class="tvs3Id tvs3Id lqNvvd lITmO WfKKme" jsname="mgY0Ed" srcset="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=h24-rw 1x, https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=h48-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=h24-rw" loading="lazy"><a href="./publications/CAAqBggKMLqiLTCnmQU?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="wEwyrc AVN2gc WfKKme " data-n-tid="9">Mathrubhumi</a></div>
												<h4 class="ipQwMb ekueJc RD0gLb"><a href="./articles/CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk?uo=CAUiANIBAA&amp;hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="DY5T1d RZIKme"><?php echo $news->title; ?></a></h4>
												<div class="QmrVtf RD0gLb kybdz">
													<div class="SVJrMe" jsname="Hn1wIf">
														<svg height="18" viewBox="0 0 24 24" width="18" focusable="false" class="N3ElHc eLNT1d uQIVzc NMm5M">
															<path d="M0 0h24v24H0V0z" fill="none"></path>
															<path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"></path>
														</svg>
														<time class="WW6dff uQIVzc Sksgp" datetime="2022-04-25T09:01:48Z">9 മണിക്കൂർ മുമ്പ്</time>
													</div>
													<menu class="fmkQje gXqRq"><span class=" L8PZAb GB1Zid" jscontroller="jSvZHb" jsmodel="WDTLsd BZ12ub" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;$15 tbf4if;ui|124+10adb768-9313-425c-b83f-0798fe1d98a7,ui|124+e599066d-71a6-40b5-be7e-8ee4631e8042;$16" jsaction="rcuQ6b:npT2md;aWRkAb:u0WEMd;h4C2te:Oy8cwd;" data-n-prms="[true,true,false,null,false,false,false,false,null,false,false]" jslog="109017"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e uUmIDd gL67me cd29Sd V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="S9Bhuc" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="കൂടുതൽ&zwj;" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-dynamic="true"><div class="XI1L0d zSBur" jsname="ksKsZd"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job">more_vert</span></div>
												</span>
												</menu>
										</div>
	
										</article>
<?php
    
        }
    }
   
  }  
?>	

								</div>
							</div>
				</div>
				<div class="dSva6b JQQdOc  yETrXb Ir3o3e Au3bp R7GTQ keNKEd j7vNaf" data-n-hl="ml" jslog="134728; index:1" jsdata="AFn1Dc;;$17" jsmodel="hT8rr" data-n-ham="true">
					
				</div>
				
		</div>
		<!--Nabeel-->
		<div class="TleV1d" jsname="Hzufd" style="display:none;">
			<div class="MH4CV" jsaction="ZYIfFd:QdqIqe">
				<div class="EmVfjc CxE4Ze eLNT1d" data-loadingmessage="ലോഡുചെയ്യുന്നു..." jscontroller="qAKInc" jsaction="animationend:kWijWc;dyRcpb:dyRcpb" style="display:block;">
					<div class="Cg7hO" aria-live="assertive" jsname="vyyg5"></div>
					<div jsname="Hxlbvc" class="xu46lf">

							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: rgb(255, 255, 255); display: block; user-select: auto; shape-rendering: auto;" width="48px" height="48px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
							<circle cx="50" cy="50" fill="none" stroke="#e15b64" stroke-width="7" r="35" stroke-dasharray="164.93361431346415 56.97787143782138" style="user-select: auto;">
							  <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" values="0 50 50;360 50 50" keyTimes="0;1" style="user-select: auto;"></animateTransform>
							</circle></svg>

					</div>
				</div>
			</div>
		</div>
		</main>
		</div>
		</div>
		<c-data id="c8" jsdata=" RWTxU;_;$20"></c-data>
		</c-wiz>
		</main>
		</div>
		</div>
		</div>
		<c-data id="c9" jsdata=" RWTxU;_;$22 FxLhne;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ;$21"></c-data>
		</c-wiz>
		<div jscontroller="NG09oe" jsaction="rcuQ6b:DMq1fb" data-tracker-id=""></div>
		</div>
		</div>
		<c-data id="c10"></c-data>
		<view-header style="display: none;">
			<title>Google വാർത്ത - അവലോകനം</title>
			<meta property="og:locale" content="ml">
			<meta name="apple-itunes-app" content="app-id=459182288">
			<meta property="title" content="സമ്പൂർണ്ണ റിപ്പോർട്ട് - Google വാർത്ത">
			<meta property="og:title" content="സമ്പൂർണ്ണ റിപ്പോർട്ട് - Google വാർത്ത">
			<meta property="og:type" content="website">
			<meta property="og:url" content="https://news.google.com/stories/CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ">
			<meta property="og:site_name" content="Google വാർത്ത">
			<meta property="twitter:card" content="summary">
			<meta property="twitter:title" content="സമ്പൂർണ്ണ റിപ്പോർട്ട് - Google വാർത്ത">
			<meta name="description" content="ഈ വാർത്തയെ സംബന്ധിച്ച ഏറ്റവും പുതിയ അപ്ഡേറ്റുകൾ, പശ്ചാത്തല വിവരങ്ങൾ, കാഴ്ചപ്പാടുകൾ എന്നിവ കാണൂ.">
			<meta property="og:description" content="ഈ വാർത്തയെ സംബന്ധിച്ച ഏറ്റവും പുതിയ അപ്ഡേറ്റുകൾ, പശ്ചാത്തല വിവരങ്ങൾ, കാഴ്ചപ്പാടുകൾ എന്നിവ കാണൂ.">
			<meta property="twitter:description" content="ഈ വാർത്തയെ സംബന്ധിച്ച ഏറ്റവും പുതിയ അപ്ഡേറ്റുകൾ, പശ്ചാത്തല വിവരങ്ങൾ, കാഴ്ചപ്പാടുകൾ എന്നിവ കാണൂ.">
			<meta property="twitter:image" content="https://lh3.googleusercontent.com/VCNu4mX4quFbzXp9uFhNs0OsNVVAQsp40sctAn7671DjJCUklGaoOQqZ0lH-wYVJQv2EKwcv=rw">
			<meta property="og:image" content="https://lh3.googleusercontent.com/VCNu4mX4quFbzXp9uFhNs0OsNVVAQsp40sctAn7671DjJCUklGaoOQqZ0lH-wYVJQv2EKwcv=rw">
		</view-header>
	</c-wiz>
	<c-wiz jsrenderer="Su4kG" class="l1yCcb" id="ZCHFDb" jsshadow="" jsdata="deferred-c1" data-p="%.@.]" data-node-index="0;0" jsmodel="hc6Ubd FSc7tf" c-wiz="" style=""><div class="tGUGyc" role="tablist" jscontroller="N7SHsf" jsaction="rcuQ6b:npT2md" style="user-select: auto;"><a class="OfIKBc" role="tab" aria-selected="false" href="./foryou?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" data-n-et="269" data-n-ca-at="1" data-n-ci-ai="CAAqDggKIghDQWtTQUNnQVAB" jsaction="click:DFu69b" style=""><span class="Fmc4g" style=""><svg enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24" focusable="false" class=" NMm5M" style=""><g style=""><rect fill="none" height="24" width="24" style=""></rect></g><g style=""><path d="M22.64,11.14l-9.79-9.79c-0.5-0.5-1.27-0.45-1.72,0l-9.78,9.79c-0.66,0.66-0.26,1.45,0,1.72l9.78,9.79 c0.44,0.44,1.21,0.51,1.72,0l9.79-9.79C22.91,12.59,23.29,11.79,22.64,11.14z M13.84,13.84L12,18l-1.84-4.17L6,12l4.16-1.84L12,6 l1.84,4.16L18,12L13.84,13.84z" style=""></path></g></svg></span><span class="eKdRHb" style="">നിങ്ങൾക്ക്</span></a><a class="OfIKBc" role="tab" aria-selected="false" href="./topstories?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" data-n-et="269" data-n-ca-at="1" data-n-ci-afi="CAoiGkNCSVNEVG9MZEc5d1gzTjBiM0pwWlhNb0FBUAE" jsaction="click:oXV9Vc" style=""><span class="Fmc4g" style=""><svg height="24" viewBox="0 0 24 24" width="24" focusable="false" class=" NMm5M" style=""><path d="M15.49 13.6c.06-.53.11-1.06.11-1.6s-.05-1.07-.11-1.6h2.7c.13.51.21 1.05.21 1.6s-.08 1.09-.21 1.6h-2.7zm-1.42 4.45c.48-.89.85-1.85 1.1-2.85h2.36c-.76 1.32-1.99 2.34-3.46 2.85zm-.2-4.45h-3.74c-.07-.53-.13-1.06-.13-1.6s.06-1.08.13-1.6h3.74c.07.52.13 1.06.13 1.6s-.06 1.07-.13 1.6zM12 18.37c-.66-.96-1.18-2.02-1.53-3.17h3.06c-.35 1.14-.87 2.21-1.53 3.17zM8.82 8.8H6.46c.77-1.33 1.99-2.34 3.46-2.85-.47.89-.84 1.85-1.1 2.85zm-2.36 6.4h2.36c.26 1 .62 1.96 1.1 2.85-1.46-.51-2.69-1.52-3.46-2.85zm-.65-1.6c-.13-.51-.21-1.05-.21-1.6s.08-1.09.21-1.6h2.7c-.06.53-.11 1.06-.11 1.6s.05 1.07.11 1.6h-2.7zM12 5.63c.66.96 1.18 2.02 1.53 3.17h-3.06c.35-1.14.87-2.21 1.53-3.17zm5.54 3.17h-2.36c-.26-1-.62-1.96-1.1-2.85 1.46.51 2.69 1.53 3.46 2.85zM11.99 4C7.58 4 4 7.58 4 12s3.58 8 7.99 8c4.42 0 8.01-3.58 8.01-8s-3.58-8-8.01-8z" style=""></path><path d="M0 0h24v24H0z" fill="none" style=""></path></svg></span><span class="eKdRHb t8lQi" style="">പ്രധാന വാർത്തകൾ</span></a><a class="OfIKBc" role="tab" aria-selected="false" href="./topics/CAAqHAgKIhZDQklTQ2pvSWJHOWpZV3hmZGpJb0FBUAE?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" data-n-et="269" data-n-ca-at="1" data-n-ci-ai="CAAqHAgKIhZDQklTQ2pvSWJHOWpZV3hmZGpJb0FBUAE" jsaction="click:oXV9Vc" style=""><span class="Fmc4g" style=""><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class=" NMm5M" style=""><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zM7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 2.88-2.88 7.19-5 9.88C9.92 16.21 7 11.85 7 9z" style=""></path><circle cx="12" cy="9" r="2.5" style=""></circle></svg></span><span class="eKdRHb" style="">പ്രാദേശികം</span></a><a class="OfIKBc" role="tab" aria-selected="false" href="./my/library?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" data-n-et="269" data-n-ca-at="1" data-n-ci-si="CAQqHAgAKhgICiISQ0FrU0IyeHBZbkpoY25rb0FBUAE" jsaction="click:DFu69b" style=""><span class="Fmc4g" style=""><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class=" NMm5M" style=""><path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" style=""></path></svg></span><span class="eKdRHb t8lQi" style="">പിന്തുടരുന്നവ</span></a></div><c-data id="c1" style=""></c-data></c-wiz>
	<div class="GvMITe" style="user-select: auto;"></div>
	<c-wiz jsrenderer="pjpEcb" jsshadow="" jsdata="deferred-i55" data-p="%.@.[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],true]" data-node-index="0;0" jsmodel="hc6Ubd" c-wiz="" style="user-select: auto;">
		<div jscontroller="ikXFab" jsaction="rcuQ6b:npT2md" class="aaFlrb" style="user-select: auto;">
			<gm-raised-drawer jsshadow="" jscontroller="IERrm" jsaction="" class="SFOjKe-MV7yeb-QA0Szd fkhPsc Au3bp" jsname="QA0Szd" wiz-aria-label="navigational drawer" wiz-aria-modal="false" pivot="end" style="user-select: auto;"><div aria-expanded="false" aria-hidden="true" aria-label="navigational drawer" aria-modal="false" class="UMrnmb-yXBf7b-QA0Szd-h2P4hd " role="dialog" style=""><div class="UMrnmb-yXBf7b-QA0Szd-HhR6Cd-bF1uUb" style=""></div><div class="UMrnmb-yXBf7b-QA0Szd-QFG6Bd-bN97Pc " jsname="vkkW1" jsslot="" style="">
						<div class="j8klob" role="menu" style="user-select: auto;">
							<div jscontroller="pcJko" jsname="UKEyIb" jsmodel="FSc7tf" jsaction="rcuQ6b:npT2md;qako4e:WcyyXb;" class="zWHNCf EA71Tc" data-n-hnr="true" jslog="120718; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLDE0MV0=" ve-visible="true" style="user-select: auto;">
								<div jsaction="" jslog="120689; track:click" aria-label="പ്രധാന വാർത്തകൾ" style="user-select: auto;">
									<a class="SFllF" tabindex="0" href="./topstories?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="പ്രധാന വാർത്തകൾ" role="menuitem" style="user-select: auto;">
										<div class="PysvYb" style="user-select: auto;">
											<svg height="24" viewBox="0 0 24 24" width="24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
												<path d="M15.49 13.6c.06-.53.11-1.06.11-1.6s-.05-1.07-.11-1.6h2.7c.13.51.21 1.05.21 1.6s-.08 1.09-.21 1.6h-2.7zm-1.42 4.45c.48-.89.85-1.85 1.1-2.85h2.36c-.76 1.32-1.99 2.34-3.46 2.85zm-.2-4.45h-3.74c-.07-.53-.13-1.06-.13-1.6s.06-1.08.13-1.6h3.74c.07.52.13 1.06.13 1.6s-.06 1.07-.13 1.6zM12 18.37c-.66-.96-1.18-2.02-1.53-3.17h3.06c-.35 1.14-.87 2.21-1.53 3.17zM8.82 8.8H6.46c.77-1.33 1.99-2.34 3.46-2.85-.47.89-.84 1.85-1.1 2.85zm-2.36 6.4h2.36c.26 1 .62 1.96 1.1 2.85-1.46-.51-2.69-1.52-3.46-2.85zm-.65-1.6c-.13-.51-.21-1.05-.21-1.6s.08-1.09.21-1.6h2.7c-.06.53-.11 1.06-.11 1.6s.05 1.07.11 1.6h-2.7zM12 5.63c.66.96 1.18 2.02 1.53 3.17h-3.06c.35-1.14.87-2.21 1.53-3.17zm5.54 3.17h-2.36c-.26-1-.62-1.96-1.1-2.85 1.46.51 2.69 1.53 3.46 2.85zM11.99 4C7.58 4 4 7.58 4 12s3.58 8 7.99 8c4.42 0 8.01-3.58 8.01-8s-3.58-8-8.01-8z" style="user-select: auto;"></path>
												<path d="M0 0h24v24H0z" fill="none" style="user-select: auto;"></path>
											</svg>
										</div>
										<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">പ്രധാന വാർത്തകൾ</span></div>
									</a>
								</div>
								<div jsaction="" jslog="120690; track:click" aria-label="നിങ്ങൾക്ക്" style="user-select: auto;">
									<a class="SFllF" tabindex="0" href="./foryou?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="നിങ്ങൾക്ക്" role="menuitem" style="user-select: auto;">
										<div class="PysvYb" style="user-select: auto;">
											<svg enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
												<g style="user-select: auto;">
													<rect fill="none" height="24" width="24" style="user-select: auto;"></rect>
												</g>
												<g style="user-select: auto;">
													<path d="M22.64,11.14l-9.79-9.79c-0.5-0.5-1.27-0.45-1.72,0l-9.78,9.79c-0.66,0.66-0.26,1.45,0,1.72l9.78,9.79 c0.44,0.44,1.21,0.51,1.72,0l9.79-9.79C22.91,12.59,23.29,11.79,22.64,11.14z M13.84,13.84L12,18l-1.84-4.17L6,12l4.16-1.84L12,6 l1.84,4.16L18,12L13.84,13.84z" style="user-select: auto;"></path>
												</g>
											</svg>
										</div>
										<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">നിങ്ങൾക്ക്</span></div>
									</a>
								</div>
								<div jsaction="" jslog="120691; track:click" aria-label="പിന്തുടരുന്നു" style="user-select: auto;">
									<a class="SFllF" tabindex="0" href="./my/library?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="പിന്തുടരുന്നു" role="menuitem" style="user-select: auto;">
										<div class="PysvYb" style="user-select: auto;">
											<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
												<path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" style="user-select: auto;"></path>
											</svg>
										</div>
										<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">പിന്തുടരുന്നു</span></div>
									</a>
								</div>
								<div jsaction="" jslog="124668; track:click" aria-label="Google News ഷോക്കേസ്" style="user-select: auto;">
									<a class="SFllF" tabindex="0" href="./showcase?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="Google News ഷോക്കേസ്" role="menuitem" style="user-select: auto;">
										<div class="PysvYb" style="user-select: auto;">
											<svg enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
												<g style="user-select: auto;">
													<rect fill="none" height="24" width="24" style="user-select: auto;"></rect>
												</g>
												<g style="user-select: auto;">
													<path d="M12,11h6v2h-6V11z M6,17h12v-2H6V17z M6,13h4V7H6V13z M22,5.78v12.44c0,1.54-1.34,2.78-3,2.78H5c-1.64,0-3-1.25-3-2.78 V5.78C2,4.26,3.36,3,5,3h14C20.64,3,22,4.25,22,5.78z M19.99,12V5.78c0-0.42-0.46-0.78-1-0.78H5C4.46,5,4,5.36,4,5.78v12.44 C4,18.64,4.46,19,5,19h14c0.54,0,1-0.36,1-0.78V12H19.99z M12,9h6V7h-6V9z" style="user-select: auto;"></path>
												</g>
											</svg>
										</div>
										<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">Google News ഷോക്കേസ്</span></div>
									</a>
								</div>
								<div jsaction="" jslog="120692; track:click" aria-label="സംരക്ഷിച്ച തിരയലുകള്&zwj;" style="user-select: auto;">
									<a class="SFllF" tabindex="0" href="./my/searches?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="സംരക്ഷിച്ച തിരയലുകള്&zwj;" role="menuitem" style="user-select: auto;">
										<div class="PysvYb" style="user-select: auto;">
											<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
												<path d="M20.49 19l-5.73-5.73C15.53 12.2 16 10.91 16 9.5A6.5 6.5 0 1 0 9.5 16c1.41 0 2.7-.47 3.77-1.24L19 20.49 20.49 19zM5 9.5C5 7.01 7.01 5 9.5 5S14 7.01 14 9.5 11.99 14 9.5 14 5 11.99 5 9.5z" style="user-select: auto;"></path>
											</svg>
										</div>
										<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">സംരക്ഷിച്ച തിരയലുകള്&zwj;</span></div>
									</a>
								</div>
								<div jsname="V2bVMb" style="user-select: auto;">
									<div class="Qo7o0c" style="user-select: auto;"></div>
									<div jsaction="" jslog="120694; 3:W251bGwsbnVsbCxudWxsLG51bGwsInRvcGljX25hdjotMTI2OTQwOTY0MiIsNywxNDEsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSVFnS0lodERRa0ZUUkdkdlNVd3lNSFpOUkU1NVlYcEJVMEZ0TVhOTFFVRlFBUSJdXQ==; track:click" aria-label="ഇന്ത്യ" style="user-select: auto;">
										<a class="SFllF" tabindex="0" href="./topics/CAAqIQgKIhtDQkFTRGdvSUwyMHZNRE55YXpBU0FtMXNLQUFQAQ?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="ഇന്ത്യ" role="menuitem" style="user-select: auto;">
											<div class="PysvYb" style="user-select: auto;">
												<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
													<path d="M13.5 3.5h-9v17h2v-7h5.6l.4 2h7v-10h-5.6l-.4-2z" style="user-select: auto;"></path>
												</svg>
											</div>
											<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">ഇന്ത്യ</span></div>
										</a>
									</div>
									<div jsaction="" jslog="120694; 3:W251bGwsbnVsbCxudWxsLG51bGwsInRvcGljX25hdjotMTI2OTQwOTY0MiIsNywxNDEsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSmdnS0lpQkRRa0ZUUldkdlNVd3lNSFpOUkd4MVlsWTRVMEZ0TVhOSFowcEtWR2xuUVZBQiJdXQ==; track:click" aria-label="ലോകം" style="user-select: auto;">
										<a class="SFllF" tabindex="0" href="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="ലോകം" role="menuitem" style="user-select: auto;">
											<div class="PysvYb" style="user-select: auto;">
												<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
													<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-.61.08-1.21.21-1.78L8.99 15v1c0 1.1.9 2 2 2v1.93C7.06 19.43 4 16.07 4 12zm13.89 5.4c-.26-.81-1-1.4-1.9-1.4h-1v-3c0-.55-.45-1-1-1h-6v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41C17.92 5.77 20 8.65 20 12c0 2.08-.81 3.98-2.11 5.4z" style="user-select: auto;"></path>
												</svg>
											</div>
											<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">ലോകം</span></div>
										</a>
									</div>
									<div jsaction="" jslog="120719; 3:W251bGwsbnVsbCxudWxsLG51bGwsInRvcGljX25hdjotMTI2OTQwOTY0MiIsNywxNDEsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSEFnS0loWkRRa2xUUTJwdlNXSkhPV3BaVjNobVpHcEpiMEZCVUFFIl1d; track:click" aria-label="നിങ്ങളുടെ പ്രാദേശിക വാര്&zwj;ത്ത" style="user-select: auto;">
										<a class="SFllF" tabindex="0" href="./topics/CAAqHAgKIhZDQklTQ2pvSWJHOWpZV3hmZGpJb0FBUAE?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="നിങ്ങളുടെ പ്രാദേശിക വാര്&zwj;ത്ത" role="menuitem" style="user-select: auto;">
											<div class="PysvYb" style="user-select: auto;">
												<svg enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
													<rect fill="none" height="24" width="24" style="user-select: auto;"></rect>
													<path d="M12,2C8.13,2,5,5.13,5,9c0,5.34,4.21,6.79,6.03,12.28C11.17,21.7,11.55,22,12,22s0.83-0.3,0.97-0.72 C14.79,15.79,19,14.34,19,9C19,5.13,15.87,2,12,2z M12,11.5c-1.38,0-2.5-1.12-2.5-2.5c0-1.38,1.12-2.5,2.5-2.5s2.5,1.12,2.5,2.5 C14.5,10.38,13.38,11.5,12,11.5z" style="user-select: auto;"></path>
												</svg>
											</div>
											<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">നിങ്ങളുടെ പ്രാദേശിക വാര്&zwj;ത്ത</span></div>
										</a>
									</div>
									<div jsaction="" jslog="120694; 3:W251bGwsbnVsbCxudWxsLG51bGwsInRvcGljX25hdjotMTI2OTQwOTY0MiIsNywxNDEsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSmdnS0lpQkRRa0ZUUldkdlNVd3lNSFpOUkVweFlXNVJVMEZ0TVhOSFowcEtWR2xuUVZBQiJdXQ==; track:click" aria-label="വിനോദം" style="user-select: auto;">
										<a class="SFllF" tabindex="0" href="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNREpxYW5RU0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="വിനോദം" role="menuitem" style="user-select: auto;">
											<div class="PysvYb" style="user-select: auto;">
												<svg enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
													<g style="user-select: auto;">
														<rect fill="none" height="24" width="24" x="0" y="0" style="user-select: auto;"></rect>
													</g>
													<g style="user-select: auto;">
														<g style="user-select: auto;">
															<path d="M18,3v2h-2V3H8v2H6V3H4v18h2v-2h2v2h8v-2h2v2h2V3H18z M8,17H6v-2h2V17z M8,13H6v-2h2V13z M8,9H6V7h2V9z M18,17h-2v-2h2V17 z M18,13h-2v-2h2V13z M18,9h-2V7h2V9z" style="user-select: auto;"></path>
														</g>
													</g>
												</svg>
											</div>
											<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">വിനോദം</span></div>
										</a>
									</div>
									<div jsaction="" jslog="120694; 3:W251bGwsbnVsbCxudWxsLG51bGwsInRvcGljX25hdjotMTI2OTQwOTY0MiIsNywxNDEsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSmdnS0lpQkRRa0ZUUldkdlNVd3lNSFpOUkZwMVpFZHZVMEZ0TVhOSFowcEtWR2xuUVZBQiJdXQ==; track:click" aria-label="കായികം" style="user-select: auto;">
										<a class="SFllF" tabindex="0" href="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRFp1ZEdvU0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="കായികം" role="menuitem" style="user-select: auto;">
											<div class="PysvYb" style="user-select: auto;">
												<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M" style="user-select: auto;">
													<path d="M15.5 5.5c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zM5 12c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm0 8.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5zm5.8-10l2.4-2.4.8.8c1.3 1.3 3 2.1 5.1 2.1V9c-1.5 0-2.7-.6-3.6-1.5l-1.9-1.9c-.5-.4-1-.6-1.6-.6s-1.1.2-1.4.6L7.8 8.4c-.4.4-.6.9-.6 1.4 0 .6.2 1.1.6 1.4L11 14v5h2v-6.2l-2.2-2.3zM19 12c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm0 8.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5z" style="user-select: auto;"></path>
												</svg>
											</div>
											<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">കായികം</span></div>
										</a>
									</div>
								</div>
								<div class="Qo7o0c" style="user-select: auto;"></div>
								<div jsaction="click:Vl1baf;" jslog="120746; track:click" aria-label="ഭാഷയും മേഖലയും. മലയാളം (ഇന്ത്യ)" style="user-select: auto;"><span class="SFllF smCdcb" tabindex="0" aria-label="ഭാഷയും മേഖലയും. മലയാളം (ഇന്ത്യ)" role="menuitem" style="user-select: auto;"><div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">ഭാഷയും മേഖലയും</span><small class="Ikgmhe" aria-hidden="true" style="user-select: auto;">മലയാളം (ഇന്ത്യ)</small></div>
								</span>
							</div>
							<div jsaction="" jslog="120695; track:click" aria-label="ക്രമീകരണം" style="user-select: auto;">
								<a class="SFllF smCdcb" tabindex="0" href="./settings?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" aria-label="ക്രമീകരണം" role="menuitem" style="user-select: auto;">
									<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">ക്രമീകരണം</span></div>
								</a>
							</div>
							<div jsaction="click:ysqWEf;" data-n-et="1113" data-n-ci-wu="https://play.google.com/store/apps/details?id=com.google.android.apps.magazines&amp;referrer=news.google.com?utm_source=web&amp;utm_medium=menu&amp;utm_campaign=side_menu_promotion" data-n-ca-at="29" jslog="120747" aria-label="Android ആപ്പ് സ്വന്തമാക്കുക" style="user-select: auto;">
								<a class="SFllF smCdcb" tabindex="0" href="https://play.google.com/store/apps/details?id=com.google.android.apps.magazines&amp;referrer=news.google.com?utm_source=web&amp;utm_medium=menu&amp;utm_campaign=side_menu_promotion" target="_blank" rel="noopener noreferrer" aria-label="Android ആപ്പ് സ്വന്തമാക്കുക" role="menuitem" style="user-select: auto;">
									<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">Android ആപ്പ് സ്വന്തമാക്കുക</span></div>
									<div class="KXOmBb" style="user-select: auto;">
										<svg width="16" height="16" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M hhikbc" style="user-select: auto;">
											<path d="M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z" style="user-select: auto;"></path>
										</svg>
									</div>
								</a>
							</div>
						<div jsaction="" jslog="120750; track:click" aria-label="സഹായം" style="user-select: auto;">
							<a class="SFllF smCdcb" tabindex="0" href="https://support.google.com/googlenews?p=web&amp;hl=ml&amp;authuser=0" target="_blank" rel="noopener noreferrer" aria-label="സഹായം" role="menuitem" style="user-select: auto;">
								<div class="e20EGc" style="user-select: auto;"><span class="ICsaqd" aria-hidden="true" style="user-select: auto;">സഹായം</span></div>
								<div class="KXOmBb" style="user-select: auto;">
									<svg width="16" height="16" viewBox="0 0 24 24" focusable="false" class="hGhvff NMm5M hhikbc" style="user-select: auto;">
										<path d="M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z" style="user-select: auto;"></path>
									</svg>
								</div>
							</a>
						</div>
					</div>
					<footer class="AXKfz BKtMSb" style="user-select: auto;"><a class="VoAhOe" href="https://policies.google.com/privacy?hl=ml" target="_blank" rel="noopener noreferrer" style="user-select: auto;">സ്വകാര്യത</a> · <a class="VoAhOe" href="https://policies.google.com/terms?hl=ml" target="_blank" rel="noopener noreferrer" style="user-select: auto;">നിബന്ധനകൾ</a> · <a class="VoAhOe" href="https://about.google?hl=ml" target="_blank" rel="noopener noreferrer" style="user-select: auto;">Google നെക്കുറിച്ച്</a></footer>
				</div>
		</div></div></gm-raised-drawer>
		<div class="PCuoHe" jsname="GGAcbc" jsaction="click:mfsKib;" style="user-select: auto;"></div>
		</div>
		<c-data id="i55" jsdata=" CjGeoc;aa|124+ui|124+b3a87a23-138d-4b0a-bd67-d941c9be2e2e,3;1" style="user-select: auto;"></c-data>
	</c-wiz>
	
	<div ng-non-bindable="" style="user-select: auto;"></div>
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700|Noto+Sans+JP:400,500,700|Noto+Sans+KR:400,500,700|Roboto:400,500,700&amp;display=swap" rel="stylesheet" style="user-select: auto;">
	
	<div class="gb_Qe" style="user-select: auto; visibility: hidden; left: 8px; top: 52px; display: none;">പ്രധാന മെനു</div>
	
	
	<div id="goog-lr-151" aria-live="assertive" aria-atomic="true" style="position: absolute; top: -1000px; height: 1px; overflow: hidden;">Google വാർത്ത - അവലോകനം</div>
	<div class="liner-scroll-points-container"></div>

<div class="liner-mini-tooltip liner-disabled liner-page-text-only-tooltip liner-desktop">
	<div class="liner-page-tooltip-body-point"></div>
	<div class="liner-page-tooltip-body"> <span>Select text only</span> </div>
</div>
<div class="liner-mini-tooltip liner-enabled liner-maintain-selection liner-desktop"> <span class="liner-color-yellow liner-mini-color-circle liner-save-button" data-slot-id="0"><div class="liner-color-label">Important</div></span> <span class="liner-color-green liner-mini-color-circle liner-save-button" data-slot-id="1"><div class="liner-color-label">More important</div></span> <span class="liner-color-orange liner-mini-color-circle liner-save-button" data-slot-id="2"><div class="liner-color-label">Most Important</div></span> <span class="liner-color-violet liner-mini-color-circle liner-save-button" data-slot-id="3"><div class="liner-color-label">Key phrase</div></span> <span class="liner-color-blue liner-mini-color-circle liner-save-button" data-slot-id="4"><div class="liner-color-label">Agree</div></span> <span class="liner-color-pink liner-mini-color-circle liner-save-button" data-slot-id="5"><div class="liner-color-label">Disagree</div></span> </div>
<div class="liner-mini-button">
	<a class="liner-mb liner-save-button liner-desktop "></a>
</div>


</body></html>