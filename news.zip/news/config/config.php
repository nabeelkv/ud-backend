<?php 

	define("HOST", "localhost");
	define("USER", "id18758151_nabeel");
	define("DB", "id18758151_news");
	define("PASSWORD", "$3iByol|3qT?RFkf");

 ?>